package app.model.common;

/**
 * Created by Ionut on 11-Dec-16.
 */
public interface Item {
}

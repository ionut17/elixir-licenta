# elixir
Sistem de gestiune a:
- temelor
- proiectelor
- prezentei
- notelor

# Scop
Sistemul este extensibil dar este destinat in principal pentru studentii de la Facultatea de Informatica Iasi.

# Realizator
Iacob Robert Ionut

1. Aplicatia poate fi accesata si online la adresa: elixir.ionutrobert.com
2. Scriptul pentru baza de date este core.sql din folderul elixir.
# elixir-angular
Angular Interface that consumes the Elixir API.
